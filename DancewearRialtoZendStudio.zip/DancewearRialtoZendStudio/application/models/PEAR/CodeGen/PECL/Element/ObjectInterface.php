<?php

interface CodeGen_PECL_Element_ObjectInterface
{
  public function getName();
  public function getPayloadType();
}

?>